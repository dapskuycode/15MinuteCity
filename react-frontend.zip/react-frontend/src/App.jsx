import MapComponent from './MapComponent'
import CategoryList from './serviceCategori'

function App() {
  return (
    <div className="w-screen h-screen">
      <MapComponent />
    </div>
  )
}

export default App
